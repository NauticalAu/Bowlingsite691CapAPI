// models/leagueModel.js
const db = require('../config/db');

const LeagueModel = {
  createLeague: async (name, description, createdBy) => {
    const result = await db.query(
      `INSERT INTO league (name, description, created_by)
       VALUES ($1, $2, $3) RETURNING *`,
      [name, description, createdBy]
    );
    return result.rows[0];
  },

  joinLeague: async (leagueId, userId) => {
    const result = await db.query(
      `INSERT INTO league_member (league_id, user_id)
       VALUES ($1, $2) RETURNING *`,
      [leagueId, userId]
    );
    return result.rows[0];
  },

  getAllLeagues: async () => {
    const result = await db.query(`SELECT * FROM league`);
    return result.rows;
  }
};

module.exports = LeagueModel;
