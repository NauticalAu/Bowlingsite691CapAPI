const db = require('../config/db');

// Create a new user
const createUser = async (fullName, email, passwordHash) => {
  const query = `
    INSERT INTO users (full_name, email, password_hash)
    VALUES ($1, $2, $3) RETURNING *;
  `;
  const values = [fullName, email, passwordHash];
  const result = await db.query(query, values);
  return result.rows[0];
};

// Find user by email
const findUserByEmail = async (email) => {
  const query = `SELECT * FROM users WHERE email = $1`;
  const result = await db.query(query, [email]);
  return result.rows[0]; // may be undefined if not found
};

const updateUser = async (userId, fullName, email) => {
  const query = `
    UPDATE users
    SET full_name = $1, email = $2
    WHERE user_id = $3
    RETURNING *;
  `;
  const values = [fullName, email, userId];
  const result = await db.query(query, values);
  return result.rows[0];
};

const findUserById = async (userId) => {
  const result = await db.query('SELECT * FROM users WHERE user_id = $1', [userId]);
  return result.rows[0];
};

const updatePassword = async (userId, newPasswordHash) => {
  const result = await db.query(
    `UPDATE users SET password_hash = $1 WHERE user_id = $2 RETURNING *`,
    [newPasswordHash, userId]
  );
  return result.rows[0];
};

module.exports = {
  createUser,
  findUserByEmail,
  updateUser,
  findUserById,
  updatePassword
};

